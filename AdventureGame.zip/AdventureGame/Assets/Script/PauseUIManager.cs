using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PauseUIManager : MonoBehaviour
{
    [SerializeField] private Button mainMenuButton;
    [SerializeField] private Button restartButton;
    [SerializeField] private Button continueButton;
    [SerializeField] private Button settingButton;
    private bool pauseFlag = false;
    private Animator anim;
    void Start()
    {
        anim = GetComponent<Animator>();
        anim.updateMode = AnimatorUpdateMode.UnscaledTime;
        mainMenuButton.onClick.AddListener(OnMainMenu);
        restartButton.onClick.AddListener(OnRestart);
        continueButton.onClick.AddListener(OnContinue);
        settingButton.onClick.AddListener(OnSetting);
    }

    private void Update()
    {
        if (!pauseFlag)
        {
            return;
        }
    }
    private void OnMainMenu()
    {
        Debug.Log("���C�����j���[�ɖ߂�");
        Time.timeScale = 1.0f;
        SceneManager.LoadScene("MainMenu");
    }
    private void OnRestart()
    {
        Debug.Log("���X�^�[�g����");
        Time.timeScale = 1.0f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    private void OnContinue()
    {
        Debug.Log("�R���e�B�j���[����");
        pauseFlag = !pauseFlag;
        anim.SetTrigger("pauseClose");
        Time.timeScale = 1.0f;
    }
    private void OnSetting()
    {
        Debug.Log("�ݒ���J��");
    }
    public void TogglePause()
    {
        pauseFlag = !pauseFlag;

        if (pauseFlag)
        {
            anim.SetTrigger("pauseOpen");
            Time.timeScale = 0.0f;
        }
        else
        {
            anim.SetTrigger("pauseClose");
            Time.timeScale = 1.0f;
        }
    }
}
