using System.Collections;
using UnityEngine;

public class BlackHoleSystem : MonoBehaviour
{
    [SerializeField] private float destroyTime = 5.0f;
    void Start()
    {
        StartCoroutine(DestroyTimer());
    }
    private IEnumerator DestroyTimer()
    {
        yield return new WaitForSeconds(destroyTime);
        Destroy(gameObject);
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        EnemyPatrol enemyPatrol=collision.GetComponentInParent<EnemyPatrol>();
        if (enemyPatrol != null) enemyPatrol.isBlackHoleStay = true;
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        EnemyPatrol enemyPatrol = collision.gameObject.GetComponentInParent<EnemyPatrol>();
        if (enemyPatrol != null) enemyPatrol.isBlackHoleStay = false;
    }
}
