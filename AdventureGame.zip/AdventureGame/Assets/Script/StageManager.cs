using System.Collections;
using TMPro;
using UnityEngine;

public class StageManager : MonoBehaviour
{
    [SerializeField] private Texture2D cursorTexture;
    [SerializeField] private TextMeshProUGUI normalBlockText;
    [SerializeField] private TextMeshProUGUI fallBlockText;
    [SerializeField] private TextMeshProUGUI blackHoleText;
    [SerializeField] private GameObject infoUI;

    public int normalBlockQuantity = 1;
    public int fallBlockQuantity = 1;
    public int blackHoleQuantity = 1;
    private void Start()
    {
        Cursor.SetCursor(cursorTexture, Vector2.zero, CursorMode.Auto);
        StartCoroutine(PlayIntro());
    }
    private IEnumerator PlayIntro()
    {
        Time.timeScale = 0.0f;
        ShowStageInfo();
        yield return new WaitForSecondsRealtime(2.0f);
        infoUI.SetActive(false);
        Time.timeScale = 1.0f;
    }
    private void ShowStageInfo()
    {
        normalBlockText.text = "�~" + normalBlockQuantity;
        fallBlockText.text = "�~" + fallBlockQuantity;
        blackHoleText.text = "�~" + blackHoleQuantity;
    }
}
